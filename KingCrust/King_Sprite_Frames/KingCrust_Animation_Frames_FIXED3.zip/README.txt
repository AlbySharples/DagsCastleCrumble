King Crust Animation Frames
============================
Each folder contains individual PNG frames with transparent backgrounds.
Import the folders into Godot and create SpriteFrames animations from them.

Main animations:
Idle, Walk, TurnAround, LookUp, LookDown, Roar_Enrage, Hurt,
GroundSlam, GroundSlam_Recovery, Dash, DashEnd, JumpShockwave,
GetHit, Death, VictoryDefeated.

Effects:
GroundSlamEffect, ShockwaveEffect, CrownFall, DustPuff.

Note: The source art is a concept animation sheet, so some animation
sequences are separated into character and effect folders where the sheet
interleaves them.
