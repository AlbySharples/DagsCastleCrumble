King Crust animation frames - FIXED 3

The Walk animation was rebuilt directly from the original sprite sheet.
The neighbouring frame on the right and the panel labels were removed.
All Walk PNGs have transparent backgrounds.
