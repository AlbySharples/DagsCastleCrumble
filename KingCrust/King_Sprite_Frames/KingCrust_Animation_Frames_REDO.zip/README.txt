King Crust — rebuilt animation frames

These frames were rebuilt directly from the original 1536x1024 sprite sheet.
Each character pose is isolated individually rather than using one repeated cell width.
Neighboring poses are excluded and the sheet background is transparent.

Folders contain:
Idle, Walk, Turn_Around, Look_Up, Look_Down, Roar_Enrage, Hurt,
Ground_Slam, Dash, Dash_End, Jump_Shockwave, Get_Hit, Death, Victory.
Ground slam shockwave effects are in Effects/Ground_Slam_Shockwave.

Import the PNGs into Godot and add them to AnimatedSprite/SpriteFrames.
